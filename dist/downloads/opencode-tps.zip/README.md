# OpenCode TPS（兼容 OpenChamber）

一个本地小工具：在 OpenCode（桌面版 / CLI）生成回复时，用一个小浮球实时显示 token 速度；同时兼容 OpenChamber。

- 默认 68px 半透明浮球，显示当前最快会话的 `tok/s`
- 点击浮球展开紧凑面板，多会话分行显示，顺序固定
- 只在会话真正进行时出现；全部结束自动消失
- 不修改 OpenChamber 配置，不联网，无遥测

> 非官方社区工具，随包提供源码供个人使用。

## 环境

- Windows 10 / 11
- OpenCode 2.x（桌面版 / CLI，插件目录与 OpenChamber 共用）
- 或 OpenChamber 2.5+（内置 OpenCode 2.x，使用 v2 插件事件接口）
- Python 3.10+，需要自带 Tkinter（官方 Windows 安装包默认包含）

## 安装

1. 解压整个压缩包。
2. 右键 `install.ps1`，选择“使用 PowerShell 运行”；
   或在 PowerShell 中执行：

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\install.ps1
   ```

3. 安装脚本会：
   - 把插件复制到 `%USERPROFILE%\.config\opencode\plugins\tps-live.js`
     （OpenChamber 与 OpenCode 共用这个插件目录）
   - 把悬浮窗程序复制到 `%LOCALAPPDATA%\OpenChamberTps`
   - 在“启动”文件夹创建 `OpenCode TPS.lnk`（旧版名称为 `OpenChamber TPS.lnk`）
   - 启动后台守护进程
4. 重启一次 OpenCode 或 OpenChamber，然后发一条消息。

> 安装目录与状态目录沿用 `OpenChamberTps`，以便兼容已安装版本。

## 使用

- 单击浮球：展开面板
- 单击面板任意位置：收回浮球
- 按住拖动：移动位置
- 右键：展开 / 收起 / 隐藏 30 秒 / 退出监控
- 没有活动会话时浮球自动消失；下一条消息开始生成时会重新出现

> 流式阶段显示的速度是基于增量文本的估算值（前面带 `≈`）；
> 回合结束时使用 provider 返回的 token 数校正，显示精确平均速度。

## 文件结构

```
install.ps1
uninstall.ps1
plugin/tps-live.js       OpenCode 插件（OpenChamber 共用）
app/common.py            路径、进程检测、互斥
app/overlay.py           Tkinter 浮球 / 面板
app/watcher.py           随 OpenCode / OpenChamber 启停的守护进程
```

## 卸载

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1
```

或手动删除：

- 启动文件夹中的 `OpenCode TPS.lnk`（旧版为 `OpenChamber TPS.lnk`）
- `%USERPROFILE%\.config\opencode\plugins\tps-live.js`
- `%LOCALAPPDATA%\OpenChamberTps`
- 结束命令行中包含 `OpenChamberTps` 的 `pythonw.exe` 进程

## 隐私

- 不发送网络请求，不读取 API Key
- 插件只订阅 OpenCode 的本地会话事件，并把当前速度写入
  `%LOCALAPPDATA%\OpenChamberTps\state-*.json`
  （`state-openchamber-*` / `state-opencode-*`）
- 悬浮窗只读取这些本地状态文件；OpenCode 和 OpenChamber 的会话会合并显示

## 常见问题

**浮球没有出现？**
确认当前有会话正在思考 / 输出 / 执行工具；空闲时浮球会自动隐藏。也可以重启 OpenCode 或
OpenChamber，或查看 `%LOCALAPPDATA%\OpenChamberTps\plugin.log`。

**OpenCode 和 OpenChamber 能同时用吗？**
可以。两个程序的会话会一起显示，顺序按首次出现固定，最多显示 4 行。

**会影响 OpenCode / OpenChamber 吗？**
插件只读事件，不修改界面和配置；卸载时删掉插件文件即可。

**支持 macOS / Linux 吗？**
核心插件与 Tkinter 悬浮窗代码本身是跨平台的，但当前安装包只包含 Windows 的安装、启动项和守护进程实现。
